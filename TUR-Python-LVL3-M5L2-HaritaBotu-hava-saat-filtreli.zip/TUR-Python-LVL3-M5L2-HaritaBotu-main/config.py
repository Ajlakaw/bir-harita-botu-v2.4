import os

# Bot tokenini koda yazmak yerine ortam değişkeninden okumak daha güvenlidir.
TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
