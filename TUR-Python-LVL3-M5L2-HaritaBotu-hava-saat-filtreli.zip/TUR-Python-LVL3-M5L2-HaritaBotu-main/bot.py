import tempfile
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

import aiohttp
import discord
from discord.ext import commands

from config import TOKEN
from logic import DB_Map


manager = DB_Map("database.db")
manager.create_user_table()

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"
MAX_MAP_CITIES = 25


# Open-Meteo'nun döndürdüğü WMO hava kodlarını kısa Türkçe metne çeviriyoruz.
WEATHER_CODES = {
    0: "Acik",
    1: "Cogunlukla acik",
    2: "Parcali bulutlu",
    3: "Kapali",
    45: "Sisli",
    48: "Kirağili sis",
    51: "Hafif ciseleme",
    53: "Ciseleme",
    55: "Yogun ciseleme",
    56: "Donan ciseleme",
    57: "Yogun donan ciseleme",
    61: "Hafif yagmur",
    63: "Yagmur",
    65: "Kuvvetli yagmur",
    66: "Donan yagmur",
    67: "Kuvvetli donan yagmur",
    71: "Hafif kar",
    73: "Kar",
    75: "Yogun kar",
    77: "Kar taneleri",
    80: "Hafif saganak",
    81: "Saganak",
    82: "Kuvvetli saganak",
    85: "Hafif kar saganagi",
    86: "Kuvvetli kar saganagi",
    95: "Gok gurultulu firtina",
    96: "Dolulu firtina",
    99: "Kuvvetli dolulu firtina",
}


def parse_population(text):
    """1.000.000, 1_000_000 veya 1000000 gibi girişleri sayıya çevirir."""
    cleaned = str(text).strip().replace(".", "").replace(",", "").replace("_", "")
    if not cleaned.isdigit():
        return None
    return int(cleaned)


def population_text(number):
    return f"{int(number):,}".replace(",", ".")


def local_time_from_response(weather_data):
    """Open-Meteo timezone bilgisinden şehrin o anki yerel saatini hesaplar."""
    offset_seconds = weather_data.get("utc_offset_seconds")
    if offset_seconds is None:
        # Yedek olarak current.time kullanılır.
        value = weather_data.get("current", {}).get("time")
        if not value:
            return None
        try:
            return datetime.fromisoformat(value).strftime("%H:%M")
        except ValueError:
            return value[11:16] if len(value) >= 16 else value

    city_now = datetime.now(timezone.utc) + timedelta(seconds=int(offset_seconds))
    return city_now.strftime("%H:%M")


async def get_weather_and_time(cities):
    """Bir grup şehir için tek istekte güncel hava + yerel saati alır.

    Open-Meteo birden fazla koordinatı virgülle ayrılmış biçimde kabul eder.
    timezone=auto sayesinde her koordinat yerel saat dilimine çözülür.
    """
    if not cities:
        return {}

    params = {
        "latitude": ",".join(str(city["lat"]) for city in cities),
        "longitude": ",".join(str(city["lng"]) for city in cities),
        "current": "temperature_2m,apparent_temperature,weather_code",
        "timezone": "auto",
        "forecast_days": 1,
    }

    timeout = aiohttp.ClientTimeout(total=12)
    try:
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(OPEN_METEO_URL, params=params) as response:
                response.raise_for_status()
                data = await response.json()
    except (aiohttp.ClientError, TimeoutError, ValueError):
        # İnternet/API sorunu haritanın tamamen bozulmasına sebep olmasın.
        return {}

    # Tek koordinatta dict, birden fazla koordinatta list döner.
    responses = data if isinstance(data, list) else [data]
    result = {}

    for city, weather_data in zip(cities, responses):
        current = weather_data.get("current", {})
        code = current.get("weather_code")
        result[city["id"]] = {
            "temperature": current.get("temperature_2m"),
            "apparent_temperature": current.get("apparent_temperature"),
            "weather": WEATHER_CODES.get(code, f"Kod {code}" if code is not None else None),
            "time": local_time_from_response(weather_data),
        }

    return result


async def send_map(ctx: commands.Context, cities, message: str, title="Şehir Haritası"):
    """Haritayı oluşturur, güncel bilgileri ekler ve Discord'a gönderir."""
    city_records = []
    for city in cities:
        if isinstance(city, dict):
            city_records.append(city)
        else:
            details = manager.get_city_details(str(city))
            if details:
                city_records.append(details)

    if not city_records:
        await ctx.send("Haritada gösterilebilecek geçerli bir şehir bulunamadı.")
        return

    # Çok fazla etiket okunmaz hale geldiği ve API isteği büyüdüğü için sınır koyuyoruz.
    city_records = city_records[:MAX_MAP_CITIES]
    extras = await get_weather_and_time(city_records)

    map_path = Path(tempfile.gettempdir()) / f"city_map_{uuid.uuid4().hex}.png"
    marker_color = manager.get_marker_color(ctx.author.id)

    try:
        ok = manager.create_graph(
            map_path,
            city_records,
            marker_color=marker_color,
            city_extras=extras,
            title=title,
        )
        if not ok:
            await ctx.send("Haritada gösterilebilecek geçerli bir şehir bulunamadı.")
            return

        if len(cities) > MAX_MAP_CITIES:
            message += f"\n(Not: haritada en fazla {MAX_MAP_CITIES} şehir gösteriliyor.)"

        if not extras:
            message += "\n⚠️ Hava servisine ulaşılamadı, harita hava/saat bilgisi olmadan hazırlandı."

        await ctx.send(message, file=discord.File(str(map_path), filename="city_map.png"))
    finally:
        try:
            map_path.unlink(missing_ok=True)
        except OSError:
            pass


@bot.event
async def on_ready():
    print(f"Bot başlatıldı! Giriş yapılan bot: {bot.user}")


@bot.command(aliases=["start"])
async def başla(ctx: commands.Context):
    await ctx.send(
        f"Merhaba, {ctx.author.name}! Mevcut komutları görmek için `!yardım_et` yazabilirsin."
    )


@bot.command(aliases=["help_me"])
async def yardım_et(ctx: commands.Context):
    current_color = manager.get_marker_color(ctx.author.id)
    await ctx.send(
        "**Harita Botu komutları**\n"
        "`!şehri_göster <şehir>` - Bir şehri hava ve saatiyle gösterir.\n"
        "`!şehri_kaydet <şehir>` - Şehri kişisel listene kaydeder.\n"
        "`!şehirlerimi_göster` - Kaydettiğin şehirleri gösterir.\n"
        "`!ülkeye_göre <ülke>` - Belirli ülkedeki en kalabalık şehirleri gösterir.\n"
        "`!nüfusa_göre <min_nüfus>` - En az bu nüfusa sahip şehirleri gösterir.\n"
        "`!ülke_nüfus <ülke> <min_nüfus>` - Ülke + nüfus filtresini birlikte kullanır.\n"
        "`!işaretçi_rengi <renk>` - Şehir işaretçisi rengini değiştirir.\n\n"
        "Örnekler:\n"
        "`!ülkeye_göre Turkey`\n"
        "`!nüfusa_göre 5000000`\n"
        "`!ülke_nüfus Turkey 1000000`\n\n"
        "Haritadaki şehir etiketlerinde güncel hava, yerel saat ve nüfus da gösterilir.\n"
        "Ülke adlarını veritabanındaki İngilizce haliyle yaz: `Turkey`, `Japan`, `United States` gibi.\n"
        f"Şu anki işaretçi rengin: `{current_color}`"
    )


@bot.command(aliases=["show_city"])
async def şehri_göster(ctx: commands.Context, *, city_name=""):
    city_name = city_name.strip()
    if not city_name:
        await ctx.send("Kullanım: `!şehri_göster <şehir>`\nÖrnek: `!şehri_göster Istanbul`")
        return

    city = manager.get_city_details(city_name)
    if city is None:
        await ctx.send(f"`{city_name}` veri tabanında bulunamadı.")
        return

    await send_map(
        ctx,
        [city],
        f"📍 **{city['city']}** haritada güncel bilgileriyle gösteriliyor:",
        title=f"{city['city']} • Güncel Hava ve Saat",
    )


@bot.command(aliases=["show_my_cities"])
async def şehirlerimi_göster(ctx: commands.Context):
    cities = manager.select_cities(ctx.author.id)
    if not cities:
        await ctx.send("Henüz kayıtlı şehrin yok. Önce `!şehri_kaydet <şehir>` kullan.")
        return

    await send_map(
        ctx,
        cities,
        f"🗺️ Kaydettiğin **{len(cities)} şehir** haritada gösteriliyor:",
        title="Kaydettiğim Şehirler • Hava ve Yerel Saat",
    )


@bot.command(aliases=["remember_city"])
async def şehri_kaydet(ctx: commands.Context, *, city_name=""):
    city_name = city_name.strip()
    if not city_name:
        await ctx.send("Kullanım: `!şehri_kaydet <şehir>`\nÖrnek: `!şehri_kaydet Antalya`")
        return

    if manager.add_city(ctx.author.id, city_name):
        await ctx.send(f"✅ **{city_name}** şehri başarıyla kaydedildi!")
    else:
        await ctx.send("Şehir bulunamadı. Şehir adını kontrol et.")


@bot.command(name="ülkeye_göre", aliases=["country", "country_cities"])
async def ülkeye_göre(ctx: commands.Context, *, country=""):
    country = country.strip()
    if not country:
        await ctx.send("Kullanım: `!ülkeye_göre <ülke>`\nÖrnek: `!ülkeye_göre Turkey`")
        return

    cities = manager.get_cities_by_country(country, limit=MAX_MAP_CITIES)
    if not cities:
        await ctx.send(f"`{country}` adına ait şehir bulunamadı. Ülke adını İngilizce dene.")
        return

    await send_map(
        ctx,
        cities,
        f"🌍 **{country}** içindeki en kalabalık {len(cities)} şehir:",
        title=f"{country} • En Kalabalık Şehirler",
    )


@bot.command(name="nüfusa_göre", aliases=["population", "population_density"])
async def nüfusa_göre(ctx: commands.Context, min_population_text=""):
    min_population = parse_population(min_population_text)
    if min_population is None:
        await ctx.send(
            "Kullanım: `!nüfusa_göre <minimum_nüfus>`\n"
            "Örnek: `!nüfusa_göre 5000000`"
        )
        return

    cities = manager.get_cities_by_population(min_population, limit=MAX_MAP_CITIES)
    if not cities:
        await ctx.send("Bu nüfus sınırına uyan şehir bulunamadı.")
        return

    await send_map(
        ctx,
        cities,
        f"👥 Nüfusu **{population_text(min_population)}+** olan en kalabalık şehirler:",
        title=f"Nüfus ≥ {population_text(min_population)}",
    )


@bot.command(name="ülke_nüfus", aliases=["country_population"])
async def ülke_nüfus(ctx: commands.Context, *, query=""):
    query = query.strip()
    if " " not in query:
        await ctx.send(
            "Kullanım: `!ülke_nüfus <ülke> <minimum_nüfus>`\n"
            "Örnek: `!ülke_nüfus Turkey 1000000`\n"
            "Çok kelimeli ülke de olur: `!ülke_nüfus United States 5000000`"
        )
        return

    country, min_population_text = query.rsplit(" ", 1)
    country = country.strip()
    min_population = parse_population(min_population_text)

    if not country or min_population is None:
        await ctx.send("Örnek kullanım: `!ülke_nüfus Turkey 1000000`")
        return

    cities = manager.get_cities_by_country_and_population(
        country,
        min_population,
        limit=MAX_MAP_CITIES,
    )
    if not cities:
        await ctx.send("Bu ülke + nüfus filtresine uyan şehir bulunamadı.")
        return

    await send_map(
        ctx,
        cities,
        f"🌍 **{country}** içinde nüfusu **{population_text(min_population)}+** olan şehirler:",
        title=f"{country} • Nüfus ≥ {population_text(min_population)}",
    )


@bot.command(name="işaretçi_rengi", aliases=["marker_color", "renk"])
async def işaretçi_rengi(ctx: commands.Context, *, color=""):
    color = color.strip()
    if not color:
        current_color = manager.get_marker_color(ctx.author.id)
        await ctx.send(
            "Kullanım: `!işaretçi_rengi <renk>`\n"
            "Örnek: `!işaretçi_rengi purple` veya `!işaretçi_rengi #00aa88`\n"
            f"Şu anki rengin: `{current_color}`"
        )
        return

    if not manager.set_marker_color(ctx.author.id, color):
        await ctx.send(
            f"`{color}` geçerli bir renk değil. `red`, `blue`, `purple` veya HEX deneyebilirsin."
        )
        return

    await ctx.send(f"🎨 İşaretçi rengin `{color}` olarak kaydedildi.")


@bot.event
async def on_command_error(ctx: commands.Context, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("Böyle bir komut yok. `!yardım_et` yazabilirsin.")
        return
    raise error


if __name__ == "__main__":
    if not TOKEN:
        raise RuntimeError(
            "Discord bot tokeni bulunamadı. DISCORD_TOKEN ortam değişkenini ayarla."
        )
    bot.run(TOKEN)
