import sqlite3

import matplotlib

matplotlib.use("Agg")  # Discord botunda pencere açmadan haritayı kaydetmek için
import matplotlib.pyplot as plt
from matplotlib.colors import is_color_like

import cartopy.crs as ccrs
import cartopy.feature as cfeature


DEFAULT_MARKER_COLOR = "red"
LAND_COLOR = "#C9D8A5"
OCEAN_COLOR = "#A9D4E8"
LAKE_COLOR = "#8EC9E6"
RIVER_COLOR = "#2F7FAE"
BORDER_COLOR = "#555555"
COAST_COLOR = "#3F3F3F"


class DB_Map:
    def __init__(self, database):
        self.database = database

    def create_user_table(self):
        """Kullanıcı şehirlerini ve harita tercihlerini tutan tabloları oluşturur."""
        conn = sqlite3.connect(self.database)
        with conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS users_cities (
                       user_id INTEGER,
                       city_id INTEGER,
                       FOREIGN KEY(city_id) REFERENCES cities(id)
                   )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS user_map_settings (
                       user_id INTEGER PRIMARY KEY,
                       marker_color TEXT NOT NULL DEFAULT 'red'
                   )"""
            )
            conn.commit()

    def add_city(self, user_id, city_name):
        city = self.get_city_details(city_name)
        if city is None:
            return 0

        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                """SELECT 1 FROM users_cities
                   WHERE user_id = ? AND city_id = ? LIMIT 1""",
                (user_id, city["id"]),
            )
            if cursor.fetchone() is None:
                conn.execute(
                    "INSERT INTO users_cities (user_id, city_id) VALUES (?, ?)",
                    (user_id, city["id"]),
                )
                conn.commit()
        return 1

    def select_cities(self, user_id):
        """Kullanıcının kaydettiği şehirleri ayrıntılarıyla döndürür."""
        conn = sqlite3.connect(self.database)
        conn.row_factory = sqlite3.Row
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                """SELECT cities.id, cities.city, cities.lat, cities.lng,
                          cities.country, cities.population
                   FROM users_cities
                   JOIN cities ON users_cities.city_id = cities.id
                   WHERE users_cities.user_id = ?
                   ORDER BY users_cities.rowid""",
                (user_id,),
            )
            return [dict(row) for row in cursor.fetchall()]

    def set_marker_color(self, user_id, color):
        color = color.strip()
        if not color or not is_color_like(color):
            return False

        conn = sqlite3.connect(self.database)
        with conn:
            conn.execute(
                """INSERT INTO user_map_settings (user_id, marker_color)
                   VALUES (?, ?)
                   ON CONFLICT(user_id)
                   DO UPDATE SET marker_color = excluded.marker_color""",
                (user_id, color),
            )
            conn.commit()
        return True

    def get_marker_color(self, user_id):
        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT marker_color FROM user_map_settings WHERE user_id = ?",
                (user_id,),
            )
            row = cursor.fetchone()

        if row and is_color_like(row[0]):
            return row[0]
        return DEFAULT_MARKER_COLOR

    def get_city_details(self, city_name):
        """Şehrin koordinat, ülke ve nüfus bilgilerini döndürür."""
        city_name = city_name.strip()
        if not city_name:
            return None

        conn = sqlite3.connect(self.database)
        conn.row_factory = sqlite3.Row
        with conn:
            cursor = conn.cursor()
            # Aynı isimde birkaç şehir varsa en kalabalık olanı seçiyoruz.
            cursor.execute(
                """SELECT id, city, lat, lng, country, population
                   FROM cities
                   WHERE city = ? COLLATE NOCASE
                   ORDER BY CAST(population AS INTEGER) DESC
                   LIMIT 1""",
                (city_name,),
            )
            row = cursor.fetchone()
            return dict(row) if row else None

    def get_coordinates(self, city_name):
        city = self.get_city_details(city_name)
        if city is None:
            return None
        return city["lat"], city["lng"]

    def _filter_cities(
        self,
        country=None,
        min_population=None,
        max_population=None,
        limit=25,
    ):
        """Ülke ve/veya nüfusa göre şehirleri filtreler.

        Not: Projedeki cities tablosunda şehir alanı bulunmadığı için gerçek
        kişi/km² nüfus yoğunluğu hesaplanamaz. Bu nedenle ödevdeki nüfus
        yoğunluğu filtresi, mevcut ``population`` alanı üzerinden yapılır.
        """
        try:
            limit = int(limit)
        except (TypeError, ValueError):
            limit = 25
        limit = max(1, min(limit, 50))

        conditions = []
        params = []

        if country:
            conditions.append("country = ? COLLATE NOCASE")
            params.append(country.strip())
        if min_population is not None:
            conditions.append("CAST(population AS INTEGER) >= ?")
            params.append(int(min_population))
        if max_population is not None:
            conditions.append("CAST(population AS INTEGER) <= ?")
            params.append(int(max_population))

        where = ""
        if conditions:
            where = "WHERE " + " AND ".join(conditions)

        query = f"""SELECT id, city, lat, lng, country, population
                    FROM cities
                    {where}
                    ORDER BY CAST(population AS INTEGER) DESC
                    LIMIT ?"""
        params.append(limit)

        conn = sqlite3.connect(self.database)
        conn.row_factory = sqlite3.Row
        with conn:
            cursor = conn.cursor()
            cursor.execute(query, params)
            return [dict(row) for row in cursor.fetchall()]

    def get_cities_by_country(self, country, limit=25):
        return self._filter_cities(country=country, limit=limit)

    def get_cities_by_population(self, min_population, limit=25):
        return self._filter_cities(min_population=min_population, limit=limit)

    def get_cities_by_country_and_population(self, country, min_population, limit=25):
        return self._filter_cities(
            country=country,
            min_population=min_population,
            limit=limit,
        )

    @staticmethod
    def _add_base_features(ax):
        """Rölyef arka planı + nehir/göl/sınır/kıyı katmanlarını ekler."""
        try:
            ax.stock_img()
        except (OSError, ValueError):
            ax.set_facecolor(OCEAN_COLOR)
            ax.add_feature(
                cfeature.OCEAN.with_scale("110m"),
                facecolor=OCEAN_COLOR,
                edgecolor="none",
                zorder=0,
            )
            ax.add_feature(
                cfeature.LAND.with_scale("110m"),
                facecolor=LAND_COLOR,
                edgecolor="none",
                zorder=0,
            )

        ax.add_feature(
            cfeature.LAKES.with_scale("110m"),
            facecolor=LAKE_COLOR,
            edgecolor=RIVER_COLOR,
            linewidth=0.35,
            alpha=0.78,
            zorder=2,
        )
        ax.add_feature(
            cfeature.RIVERS.with_scale("110m"),
            edgecolor=RIVER_COLOR,
            linewidth=0.60,
            alpha=0.9,
            zorder=3,
        )
        ax.add_feature(
            cfeature.BORDERS.with_scale("110m"),
            edgecolor=BORDER_COLOR,
            linewidth=0.45,
            alpha=0.8,
            zorder=3,
        )
        ax.add_feature(
            cfeature.COASTLINE.with_scale("110m"),
            edgecolor=COAST_COLOR,
            linewidth=0.55,
            alpha=0.9,
            zorder=3,
        )

    @staticmethod
    def _population_text(population):
        if population is None:
            return "?"
        try:
            population = int(population)
        except (TypeError, ValueError):
            return "?"
        if population >= 1_000_000:
            return f"{population / 1_000_000:.1f}M"
        if population >= 1_000:
            return f"{population / 1_000:.0f}K"
        return str(population)

    def _normalize_cities(self, cities):
        if isinstance(cities, (str, dict)):
            cities = [cities]

        result = []
        for city in cities:
            if isinstance(city, dict):
                if {"id", "city", "lat", "lng"}.issubset(city):
                    result.append(city)
            else:
                details = self.get_city_details(str(city))
                if details:
                    result.append(details)
        return result

    def create_graph(
        self,
        path,
        cities,
        marker_color=DEFAULT_MARKER_COLOR,
        city_extras=None,
        title="Şehir Haritası • Doğal Rölyef",
    ):
        """Şehirleri hava, yerel saat ve nüfus bilgileriyle haritada gösterir."""
        city_points = self._normalize_cities(cities)
        if not city_points:
            return False

        if not is_color_like(marker_color):
            marker_color = DEFAULT_MARKER_COLOR

        city_extras = city_extras or {}

        fig = plt.figure(figsize=(15, 8.5))
        ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
        ax.set_global()
        self._add_base_features(ax)

        for city in city_points:
            lat = city["lat"]
            lng = city["lng"]

            ax.plot(
                lng,
                lat,
                marker="o",
                markersize=8,
                color=marker_color,
                markeredgecolor="white",
                markeredgewidth=1.0,
                transform=ccrs.PlateCarree(),
                zorder=5,
            )

            extra = city_extras.get(city["id"], {})
            label = city["city"]

            # Filtreli haritalarda ülke ve nüfus da görünür.
            if city.get("country"):
                label += f" ({city['country']})"
            if city.get("population") is not None:
                label += f"\nNufus: {self._population_text(city['population'])}"

            temperature = extra.get("temperature")
            weather = extra.get("weather")
            local_time = extra.get("time")

            if temperature is not None:
                weather_text = f"{temperature:.1f} C"
                if weather:
                    weather_text += f" • {weather}"
                label += f"\nHava: {weather_text}"
            elif weather:
                label += f"\nHava: {weather}"

            if local_time:
                label += f"\nSaat: {local_time}"

            ax.text(
                lng + 1.4,
                lat + 1.4,
                label,
                fontsize=7.2,
                transform=ccrs.PlateCarree(),
                bbox={
                    "facecolor": "white",
                    "alpha": 0.80,
                    "edgecolor": "#777777",
                    "linewidth": 0.3,
                    "pad": 1.6,
                },
                zorder=6,
            )

        ax.set_title(title, fontsize=15, pad=12)
        fig.text(
            0.01,
            0.012,
            "Guncel hava ve yerel saat: Open-Meteo",
            fontsize=7.5,
            alpha=0.75,
        )
        fig.tight_layout(rect=(0, 0.025, 1, 1))
        fig.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
        plt.close(fig)
        return True

    def draw_distance(self, city1, city2):
        coordinates1 = self.get_coordinates(city1)
        coordinates2 = self.get_coordinates(city2)
        if coordinates1 is None or coordinates2 is None:
            return False

        lat1, lng1 = coordinates1
        lat2, lng2 = coordinates2
        plt.plot(
            [lng1, lng2],
            [lat1, lat2],
            color="blue",
            linewidth=2,
            transform=ccrs.Geodetic(),
            zorder=2,
        )
        return True


if __name__ == "__main__":
    m = DB_Map("database.db")
    m.create_user_table()
