import os

# Bot tokenini koda yazmak yerine ortam değişkeninden okumak daha güvenlidir.
TOKEN = "buraya token"