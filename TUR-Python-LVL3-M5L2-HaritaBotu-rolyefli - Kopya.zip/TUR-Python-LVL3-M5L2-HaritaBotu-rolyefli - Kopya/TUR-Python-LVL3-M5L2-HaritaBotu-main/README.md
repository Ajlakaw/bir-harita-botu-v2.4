# 🗺️ Harita Botu

Bu proje, Discord üzerinden şehirleri dünya haritasında göstermeyi ve kullanıcıların seçtiği şehirleri SQLite veri tabanında kaydetmeyi sağlayan bir bottur.

Projeyle birlikte gelen `database.db` dosyasında dünyanın çok sayıda şehri, enlem ve boylam bilgileriyle birlikte bulunur.

## Özellikler

- Belirtilen bir şehri dünya haritasında işaretler.
- Kullanıcının seçtiği şehirleri kişisel listesine kaydeder.
- Kullanıcının kaydettiği tüm şehirleri tek bir haritada gösterir.
- Kullanıcı kendi **işaretçi rengini** seçebilir; seçim SQLite'ta saklanır.
- Cartopy’nin **Natural Earth shaded relief** arka planıyla dağlar ve arazi yükseltileri doğal rölyef görünümünde gösterilir.
- **Nehirler, göller, kıyılar ve ülke sınırları** rölyefin üzerine ayrıca çizilir.
- Rölyef rasterı kullanılamazsa bot otomatik olarak düz renkli **kara/okyanus** görünümüne geri döner.
- Haritaları Cartopy + Matplotlib ile PNG olarak oluşturur ve Discord'a gönderir.

## Proje dosyaları

- `bot.py` — Discord komutları ve botun ana çalışma dosyası.
- `logic.py` — SQLite işlemleri ve Cartopy harita oluşturma fonksiyonları.
- `database.db` — Şehirler ve koordinatlarını içeren veri tabanı.
- `config.py` — Discord tokenini `DISCORD_TOKEN` ortam değişkeninden okur.
- `requirements.txt` — Gerekli Python paketleri.

## Kurulum

Windows PowerShell örneği:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

> Cartopy, Natural Earth katmanlarını ilk kez kullanırken bazı harita verilerini kendi önbelleğine indirebilir. Bu nedenle ilk harita oluşturma sırasında internet bağlantısı gerekebilir.

## Discord tokenini ayarlama

Tokeni doğrudan `config.py` içine yazmak yerine ortam değişkeni kullanılır:

```powershell
$env:DISCORD_TOKEN="BURAYA_BOT_TOKENIN"
python bot.py
```

Bot komutları mesajları okuyacağı için Discord Developer Portal'da gerekli intent ayarlarının açık olduğundan emin ol.

## Komutlar

| Komut | Açıklama |
|---|---|
| `!başla` | Karşılama mesajını gösterir. |
| `!yardım_et` | Kullanılabilir komutları listeler. |
| `!şehri_göster <şehir>` | Belirtilen şehri haritada gösterir. |
| `!şehri_kaydet <şehir>` | Belirtilen şehri kullanıcı listesine kaydeder. |
| `!şehirlerimi_göster` | Kullanıcının kaydettiği tüm şehirleri haritada gösterir. |
| `!işaretçi_rengi <renk>` | Şehir işaretçilerinin rengini seçer ve kaydeder. |

İngilizce alias'lar da kullanılabilir: `!start`, `!help_me`, `!show_city`, `!remember_city`, `!show_my_cities`, `!marker_color`.

## Örnek kullanım

```text
!şehri_göster Istanbul
!şehri_kaydet Istanbul
!şehri_kaydet Antalya
!işaretçi_rengi purple
!şehirlerimi_göster
```

HEX renk de kullanılabilir:

```text
!işaretçi_rengi #00aa88
```

Geçersiz bir renk girilirse bot kullanıcıyı uyarır. Matplotlib'in tanıdığı renk adları ve HEX renkleri kabul edilir.

## Rölyef ve coğrafi katmanlar

`logic.py` içindeki `create_graph()` dünya ölçeğinde daha doğal bir görünüm için önce `ax.stock_img()` çağırır. Cartopy burada Natural Earth'ün **shaded relief** rasterını kullanır. Böylece arazi, düz yeşil kara parçaları yerine yükseltiyi hissettiren yeşil–oker–kahverengi–açık tonlarla ve gölgelerle görünür.

Rölyefin üzerine şu Cartopy özellikleri çizilir:

- `cartopy.feature.LAKES` → göller
- `cartopy.feature.RIVERS` → nehirler
- `cartopy.feature.BORDERS` → ülke sınırları
- `cartopy.feature.COASTLINE` → kıyı çizgileri

`stock_img()` kullanılamazsa kod otomatik olarak `LAND` ve `OCEAN` katmanlarını düz renklerle çizen yedek görünüme geçer. Bu sayede harita üretimi tamamen durmaz.

> Not: Bu arka plan **görsel rölyeftir**; metre cinsinden sayısal bir yükseklik veri seti değildir. Gerçek yükseklik değerleri/renk skalası istenirse SRTM veya ETOPO gibi bir DEM ayrıca eklenebilir.

## İşaretçi rengi nasıl çalışıyor?

Kullanıcı `!işaretçi_rengi <renk>` komutunu çalıştırdığında renk `user_map_settings` tablosuna kaydedilir. Sonraki haritalarda `send_map()` bu rengi alıp `create_graph(..., marker_color=...)` fonksiyonuna gönderir.

Bu sayede her Discord kullanıcısının işaretçi tercihi birbirinden bağımsızdır.

## Güvenlik

Discord bot tokenini hiçbir zaman GitHub'a commit etme. Tokeninin açığa çıktığını düşünüyorsan Discord Developer Portal üzerinden yenisini oluştur.
