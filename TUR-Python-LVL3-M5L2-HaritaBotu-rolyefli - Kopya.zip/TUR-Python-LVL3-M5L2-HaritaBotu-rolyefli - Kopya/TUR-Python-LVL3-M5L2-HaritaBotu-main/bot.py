import tempfile
import uuid
from pathlib import Path

import discord
from discord.ext import commands

from config import TOKEN
from logic import DB_Map


# Veri tabanı yöneticisini başlat.
manager = DB_Map("database.db")
manager.create_user_table()

# Komutların mesaj içeriğini okuyabilmesi için gerekli intent'ler.
intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)


async def send_map(ctx: commands.Context, cities, message: str):
    """Haritayı geçici bir PNG dosyasına kaydeder ve Discord'a gönderir."""
    map_path = Path(tempfile.gettempdir()) / f"city_map_{uuid.uuid4().hex}.png"
    marker_color = manager.get_marker_color(ctx.author.id)

    try:
        if not manager.create_graph(map_path, cities, marker_color=marker_color):
            await ctx.send("Haritada gösterilebilecek geçerli bir şehir bulunamadı.")
            return

        await ctx.send(
            message,
            file=discord.File(str(map_path), filename="city_map.png"),
        )
    finally:
        try:
            map_path.unlink(missing_ok=True)
        except OSError:
            pass


@bot.event
async def on_ready():
    print(f"Bot başlatıldı! Giriş yapılan bot: {bot.user}")


@bot.command(aliases=["start"])
async def başla(ctx: commands.Context):
    await ctx.send(
        f"Merhaba, {ctx.author.name}! Mevcut komutları görmek için `!yardım_et` yazabilirsin."
    )


@bot.command(aliases=["help_me"])
async def yardım_et(ctx: commands.Context):
    current_color = manager.get_marker_color(ctx.author.id)
    await ctx.send(
        "**Harita Botu komutları**\n"
        "`!başla` - Botun karşılama mesajını gösterir.\n"
        "`!şehri_göster <şehir>` - Belirtilen şehri haritada gösterir.\n"
        "`!şehri_kaydet <şehir>` - Şehri kişisel listene kaydeder.\n"
        "`!şehirlerimi_göster` - Kaydettiğin tüm şehirleri tek haritada gösterir.\n"
        "`!işaretçi_rengi <renk>` - Şehir işaretçilerinin rengini değiştirir.\n\n"
        f"Şu anki işaretçi rengin: `{current_color}`\n"
        "Renk örnekleri: `red`, `blue`, `purple`, `orange`, `#00aa88`.\n\n"
        "Haritada kara ve okyanuslar renklendirilir; nehirler, göller ve dağ/yükselti "
        "noktaları da Cartopy + Natural Earth verileriyle gösterilir.\n\n"
        "Not: Şehir adlarını veri tabanındaki İngilizce adlarıyla yazman en iyi sonucu verir. "
        "Örnek: `!şehri_göster Istanbul`"
    )


@bot.command(aliases=["show_city"])
async def şehri_göster(ctx: commands.Context, *, city_name=""):
    city_name = city_name.strip()

    if not city_name:
        await ctx.send("Kullanım: `!şehri_göster <şehir>`\nÖrnek: `!şehri_göster Istanbul`")
        return

    if manager.get_coordinates(city_name) is None:
        await ctx.send(
            f"`{city_name}` veri tabanında bulunamadı. Şehir adını İngilizce olarak kontrol et."
        )
        return

    await send_map(ctx, [city_name], f"📍 **{city_name}** haritada gösteriliyor:")


@bot.command(aliases=["show_my_cities"])
async def şehirlerimi_göster(ctx: commands.Context):
    cities = manager.select_cities(ctx.author.id)

    if not cities:
        await ctx.send(
            "Henüz kayıtlı şehrin yok. Önce `!şehri_kaydet <şehir>` komutunu kullan."
        )
        return

    city_list = ", ".join(cities)
    await send_map(
        ctx,
        cities,
        f"🗺️ Kaydettiğin şehirler: **{city_list}**",
    )


@bot.command(aliases=["remember_city"])
async def şehri_kaydet(ctx: commands.Context, *, city_name=""):
    city_name = city_name.strip()

    if not city_name:
        await ctx.send("Kullanım: `!şehri_kaydet <şehir>`\nÖrnek: `!şehri_kaydet Antalya`")
        return

    if manager.add_city(ctx.author.id, city_name):
        await ctx.send(f"✅ **{city_name}** şehri başarıyla kaydedildi!")
    else:
        await ctx.send(
            "Şehir bulunamadı. Lütfen şehir adını İngilizce olarak ve komuttan sonra bir boşluk bırakarak gir."
        )


@bot.command(name="işaretçi_rengi", aliases=["marker_color", "renk"])
async def işaretçi_rengi(ctx: commands.Context, *, color=""):
    """Kullanıcının şehir işaretçilerinde kullanılacak rengi seçmesini sağlar."""
    color = color.strip()

    if not color:
        current_color = manager.get_marker_color(ctx.author.id)
        await ctx.send(
            "Kullanım: `!işaretçi_rengi <renk>`\n"
            "Örnek: `!işaretçi_rengi purple` veya `!işaretçi_rengi #00aa88`\n"
            f"Şu anki rengin: `{current_color}`"
        )
        return

    if not manager.set_marker_color(ctx.author.id, color):
        await ctx.send(
            f"`{color}` geçerli bir renk değil. "
            "Örnek olarak `red`, `blue`, `purple`, `orange` veya `#00aa88` kullanabilirsin."
        )
        return

    await ctx.send(f"🎨 İşaretçi rengin `{color}` olarak kaydedildi.")


@bot.event
async def on_command_error(ctx: commands.Context, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("Böyle bir komut yok. Komutları görmek için `!yardım_et` yazabilirsin.")
        return
    raise error


if __name__ == "__main__":
    if not TOKEN:
        raise RuntimeError(
            "Discord bot tokeni bulunamadı. DISCORD_TOKEN ortam değişkenini ayarlayıp tekrar çalıştır."
        )

    bot.run(TOKEN)
