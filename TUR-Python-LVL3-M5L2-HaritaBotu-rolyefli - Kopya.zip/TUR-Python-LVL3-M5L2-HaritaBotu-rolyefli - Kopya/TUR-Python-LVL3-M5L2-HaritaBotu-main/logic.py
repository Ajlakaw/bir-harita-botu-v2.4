import sqlite3

import matplotlib

matplotlib.use("Agg")  # Discord botunda pencere açmadan haritayı dosyaya kaydetmek için
import matplotlib.pyplot as plt
from matplotlib.colors import is_color_like

import cartopy.crs as ccrs
import cartopy.feature as cfeature


DEFAULT_MARKER_COLOR = "red"
# Düz renkli görünüm için yedek palet. Ana görünüm Cartopy'nin
# Natural Earth shaded relief (ne_shaded) rasterını kullanır.
LAND_COLOR = "#C9D8A5"
OCEAN_COLOR = "#A9D4E8"
LAKE_COLOR = "#8EC9E6"
RIVER_COLOR = "#2F7FAE"
BORDER_COLOR = "#555555"
COAST_COLOR = "#3F3F3F"


class DB_Map:
    def __init__(self, database):
        self.database = database

    def create_user_table(self):
        """Kullanıcı şehirlerini ve harita tercihlerini tutan tabloları oluşturur."""
        conn = sqlite3.connect(self.database)
        with conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS users_cities (
                       user_id INTEGER,
                       city_id INTEGER,
                       FOREIGN KEY(city_id) REFERENCES cities(id)
                   )"""
            )
            conn.execute(
                """CREATE TABLE IF NOT EXISTS user_map_settings (
                       user_id INTEGER PRIMARY KEY,
                       marker_color TEXT NOT NULL DEFAULT 'red'
                   )"""
            )
            conn.commit()

    def add_city(self, user_id, city_name):
        """Şehir varsa kullanıcının listesine ekler; yoksa 0 döndürür."""
        city_name = city_name.strip()
        if not city_name:
            return 0

        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()

            # Aynı isimde birden fazla şehir varsa nüfusu en yüksek olanı seçiyoruz.
            cursor.execute(
                """SELECT id
                   FROM cities
                   WHERE city = ? COLLATE NOCASE
                   ORDER BY population DESC
                   LIMIT 1""",
                (city_name,),
            )
            city_data = cursor.fetchone()

            if not city_data:
                return 0

            city_id = city_data[0]

            # Aynı şehrin aynı kullanıcı için tekrar kaydedilmesini engelle.
            cursor.execute(
                """SELECT 1
                   FROM users_cities
                   WHERE user_id = ? AND city_id = ?
                   LIMIT 1""",
                (user_id, city_id),
            )
            if cursor.fetchone() is None:
                conn.execute(
                    "INSERT INTO users_cities (user_id, city_id) VALUES (?, ?)",
                    (user_id, city_id),
                )
                conn.commit()

            return 1

    def select_cities(self, user_id):
        """Kullanıcının kaydettiği şehirlerin adlarını döndürür."""
        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                """SELECT cities.city
                   FROM users_cities
                   JOIN cities ON users_cities.city_id = cities.id
                   WHERE users_cities.user_id = ?
                   ORDER BY users_cities.rowid""",
                (user_id,),
            )
            return [row[0] for row in cursor.fetchall()]

    def set_marker_color(self, user_id, color):
        """Kullanıcının şehir işaretçisi rengini kaydeder.

        Matplotlib'in tanıdığı renk adları (red, blue, purple...) ve HEX renkler
        (#ff6600 gibi) kabul edilir.
        """
        color = color.strip()
        if not color or not is_color_like(color):
            return False

        conn = sqlite3.connect(self.database)
        with conn:
            conn.execute(
                """INSERT INTO user_map_settings (user_id, marker_color)
                   VALUES (?, ?)
                   ON CONFLICT(user_id)
                   DO UPDATE SET marker_color = excluded.marker_color""",
                (user_id, color),
            )
            conn.commit()
        return True

    def get_marker_color(self, user_id):
        """Kullanıcının kayıtlı işaretçi rengini veya varsayılan rengi döndürür."""
        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT marker_color FROM user_map_settings WHERE user_id = ?",
                (user_id,),
            )
            row = cursor.fetchone()

        if row and is_color_like(row[0]):
            return row[0]
        return DEFAULT_MARKER_COLOR

    def get_coordinates(self, city_name):
        """Şehrin (enlem, boylam) bilgisini döndürür."""
        city_name = city_name.strip()
        if not city_name:
            return None

        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                """SELECT lat, lng
                   FROM cities
                   WHERE city = ? COLLATE NOCASE
                   ORDER BY population DESC
                   LIMIT 1""",
                (city_name,),
            )
            return cursor.fetchone()

    @staticmethod
    def _add_base_features(ax):
        """Doğal rölyef arka planı ve coğrafi katmanları ekler.

        ``stock_img()`` Cartopy ile gelen, Natural Earth'ün gölgeli rölyef
        (shaded relief) görüntüsünü kullanır. Bu görünüm alçak alanları daha
        yeşil, yüksek alanları kahverengi/açık tonlarda gösterdiği için
        dağların biçimi ayrı üçgen simgeler kullanmadan okunabilir.

        Herhangi bir nedenle raster yüklenemezse düz kara/okyanus renklerine
        geri düşülür; böylece bot harita üretmeye devam eder.
        """
        try:
            # Cartopy'nin kendi Natural Earth shaded-relief rasterı.
            # Dünya ölçeğinde hızlıdır ve ek bir DEM dosyası gerektirmez.
            ax.stock_img()
        except (OSError, ValueError):
            ax.set_facecolor(OCEAN_COLOR)
            ax.add_feature(
                cfeature.OCEAN.with_scale("110m"),
                facecolor=OCEAN_COLOR,
                edgecolor="none",
                zorder=0,
            )
            ax.add_feature(
                cfeature.LAND.with_scale("110m"),
                facecolor=LAND_COLOR,
                edgecolor="none",
                zorder=0,
            )

        # Rölyef görüntüsünün üstüne okunaklı coğrafi çizgiler eklenir.
        ax.add_feature(
            cfeature.LAKES.with_scale("110m"),
            facecolor=LAKE_COLOR,
            edgecolor=RIVER_COLOR,
            linewidth=0.35,
            alpha=0.78,
            zorder=2,
        )
        ax.add_feature(
            cfeature.RIVERS.with_scale("110m"),
            edgecolor=RIVER_COLOR,
            linewidth=0.60,
            alpha=0.9,
            zorder=3,
        )
        ax.add_feature(
            cfeature.BORDERS.with_scale("110m"),
            edgecolor=BORDER_COLOR,
            linewidth=0.45,
            alpha=0.8,
            zorder=3,
        )
        ax.add_feature(
            cfeature.COASTLINE.with_scale("110m"),
            edgecolor=COAST_COLOR,
            linewidth=0.55,
            alpha=0.9,
            zorder=3,
        )

    def create_graph(self, path, cities, marker_color=DEFAULT_MARKER_COLOR):
        """Verilen şehirleri rölyefli dünya haritasında işaretleyip kaydeder.

        Parameters
        ----------
        path : str | pathlib.Path
            Haritanın kaydedileceği dosya yolu.
        cities : list[str] | tuple[str] | str
            Haritada gösterilecek şehir veya şehirler.
        marker_color : str
            Şehir işaretçilerinin Matplotlib uyumlu rengi.

        Returns
        -------
        bool
            En az bir geçerli şehir çizildiyse True, aksi halde False.
        """
        if isinstance(cities, str):
            cities = [cities]

        city_points = []
        for city in cities:
            coordinates = self.get_coordinates(city)
            if coordinates is not None:
                lat, lng = coordinates
                city_points.append((city, lat, lng))

        if not city_points:
            return False

        if not is_color_like(marker_color):
            marker_color = DEFAULT_MARKER_COLOR

        fig = plt.figure(figsize=(13, 7))
        ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())
        ax.set_global()

        self._add_base_features(ax)

        for city, lat, lng in city_points:
            ax.plot(
                lng,
                lat,
                marker="o",
                markersize=8,
                color=marker_color,
                markeredgecolor="white",
                markeredgewidth=1.0,
                transform=ccrs.PlateCarree(),
                zorder=5,
            )

            ax.text(
                lng + 2,
                lat + 2,
                city,
                fontsize=9,
                transform=ccrs.PlateCarree(),
                bbox={
                    "facecolor": "white",
                    "alpha": 0.78,
                    "edgecolor": "none",
                    "pad": 1.5,
                },
                zorder=6,
            )

        ax.set_title("Şehir Haritası • Doğal Rölyef", fontsize=15, pad=12)
        fig.tight_layout()
        fig.savefig(path, dpi=150, bbox_inches="tight", facecolor="white")
        plt.close(fig)
        return True

    def draw_distance(self, city1, city2):
        """Aktif Cartopy haritasında iki şehir arasına jeodezik bir çizgi çizer."""
        coordinates1 = self.get_coordinates(city1)
        coordinates2 = self.get_coordinates(city2)

        if coordinates1 is None or coordinates2 is None:
            return False

        lat1, lng1 = coordinates1
        lat2, lng2 = coordinates2

        plt.plot(
            [lng1, lng2],
            [lat1, lat2],
            color="blue",
            linewidth=2,
            transform=ccrs.Geodetic(),
            zorder=2,
        )
        return True


if __name__ == "__main__":
    m = DB_Map("database.db")
    m.create_user_table()
