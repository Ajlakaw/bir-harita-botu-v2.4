import sqlite3

import matplotlib

matplotlib.use("Agg")  # Discord botunda pencere açmadan haritayı dosyaya kaydetmek için
import matplotlib.pyplot as plt
import cartopy.crs as ccrs


class DB_Map:
    def __init__(self, database):
        self.database = database

    def create_user_table(self):
        """Kullanıcıların kaydettiği şehirleri tutan tabloyu oluşturur."""
        conn = sqlite3.connect(self.database)
        with conn:
            conn.execute(
                """CREATE TABLE IF NOT EXISTS users_cities (
                       user_id INTEGER,
                       city_id INTEGER,
                       FOREIGN KEY(city_id) REFERENCES cities(id)
                   )"""
            )
            conn.commit()

    def add_city(self, user_id, city_name):
        """Şehir varsa kullanıcının listesine ekler; yoksa 0 döndürür."""
        city_name = city_name.strip()
        if not city_name:
            return 0

        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()

            # Aynı isimde birden fazla şehir varsa nüfusu en yüksek olanı seçiyoruz.
            cursor.execute(
                """SELECT id
                   FROM cities
                   WHERE city = ? COLLATE NOCASE
                   ORDER BY population DESC
                   LIMIT 1""",
                (city_name,),
            )
            city_data = cursor.fetchone()

            if not city_data:
                return 0

            city_id = city_data[0]

            # Aynı şehrin aynı kullanıcı için tekrar kaydedilmesini engelle.
            cursor.execute(
                """SELECT 1
                   FROM users_cities
                   WHERE user_id = ? AND city_id = ?
                   LIMIT 1""",
                (user_id, city_id),
            )
            if cursor.fetchone() is None:
                conn.execute(
                    "INSERT INTO users_cities (user_id, city_id) VALUES (?, ?)",
                    (user_id, city_id),
                )
                conn.commit()

            return 1

    def select_cities(self, user_id):
        """Kullanıcının kaydettiği şehirlerin adlarını döndürür."""
        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                """SELECT cities.city
                   FROM users_cities
                   JOIN cities ON users_cities.city_id = cities.id
                   WHERE users_cities.user_id = ?
                   ORDER BY users_cities.rowid""",
                (user_id,),
            )
            return [row[0] for row in cursor.fetchall()]

    def get_coordinates(self, city_name):
        """Şehrin (enlem, boylam) bilgisini döndürür."""
        city_name = city_name.strip()
        if not city_name:
            return None

        conn = sqlite3.connect(self.database)
        with conn:
            cursor = conn.cursor()
            cursor.execute(
                """SELECT lat, lng
                   FROM cities
                   WHERE city = ? COLLATE NOCASE
                   ORDER BY population DESC
                   LIMIT 1""",
                (city_name,),
            )
            return cursor.fetchone()

    def create_graph(self, path, cities):
        """Verilen şehirleri dünya haritası üzerinde işaretleyip PNG olarak kaydeder.

        Parameters
        ----------
        path : str | pathlib.Path
            Haritanın kaydedileceği dosya yolu.
        cities : list[str] | tuple[str] | str
            Haritada gösterilecek şehir veya şehirler.

        Returns
        -------
        bool
            En az bir geçerli şehir çizildiyse True, aksi halde False.
        """
        if isinstance(cities, str):
            cities = [cities]

        city_points = []
        for city in cities:
            coordinates = self.get_coordinates(city)
            if coordinates is not None:
                lat, lng = coordinates
                city_points.append((city, lat, lng))

        if not city_points:
            return False

        fig = plt.figure(figsize=(13, 7))
        ax = fig.add_subplot(1, 1, 1, projection=ccrs.PlateCarree())

        # Cartopy ile birlikte gelen dünya görseli; ayrıca internetten harita indirmez.
        ax.stock_img()
        ax.set_global()

        for city, lat, lng in city_points:
            ax.plot(
                lng,
                lat,
                marker="o",
                markersize=7,
                color="red",
                markeredgecolor="white",
                markeredgewidth=0.8,
                transform=ccrs.PlateCarree(),
                zorder=3,
            )

            ax.text(
                lng + 2,
                lat + 2,
                city,
                fontsize=9,
                transform=ccrs.PlateCarree(),
                bbox={"facecolor": "white", "alpha": 0.75, "edgecolor": "none", "pad": 1.5},
                zorder=4,
            )

        ax.set_title("Şehir Haritası", fontsize=15, pad=12)
        fig.tight_layout()
        fig.savefig(path, dpi=150, bbox_inches="tight")
        plt.close(fig)
        return True

    def draw_distance(self, city1, city2):
        """Aktif Cartopy haritasında iki şehir arasına jeodezik bir çizgi çizer."""
        coordinates1 = self.get_coordinates(city1)
        coordinates2 = self.get_coordinates(city2)

        if coordinates1 is None or coordinates2 is None:
            return False

        lat1, lng1 = coordinates1
        lat2, lng2 = coordinates2

        plt.plot(
            [lng1, lng2],
            [lat1, lat2],
            color="blue",
            linewidth=2,
            transform=ccrs.Geodetic(),
            zorder=2,
        )
        return True


if __name__ == "__main__":
    m = DB_Map("database.db")
    m.create_user_table()
