import os
import tempfile
import uuid
from pathlib import Path

import discord
from discord.ext import commands

from config import TOKEN
from logic import DB_Map


# Veri tabanı yöneticisini başlat.
manager = DB_Map("database.db")
manager.create_user_table()

# Komutların mesaj içeriğini okuyabilmesi için gerekli intent'ler.
intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)


async def send_map(ctx: commands.Context, cities, message: str):
    """Haritayı geçici bir PNG dosyasına kaydeder ve Discord'a gönderir."""
    map_path = Path(tempfile.gettempdir()) / f"city_map_{uuid.uuid4().hex}.png"

    try:
        if not manager.create_graph(map_path, cities):
            await ctx.send("Haritada gösterilebilecek geçerli bir şehir bulunamadı.")
            return

        await ctx.send(
            message,
            file=discord.File(str(map_path), filename="city_map.png"),
        )
    finally:
        try:
            map_path.unlink(missing_ok=True)
        except OSError:
            pass


@bot.event
async def on_ready():
    print(f"Bot başlatıldı! Giriş yapılan bot: {bot.user}")


@bot.command()
async def başla(ctx: commands.Context):
    await ctx.send(
        f"Merhaba, {ctx.author.name}! Mevcut komutları görmek için `!yardım_et` yazabilirsin."
    )


@bot.command()
async def yardım_et(ctx: commands.Context):
    await ctx.send(
        "**Harita Botu komutları**\n"
        "`!başla` - Botun karşılama mesajını gösterir.\n"
        "`!şehri_göster <şehir>` - Belirtilen şehri haritada gösterir.\n"
        "`!şehri_kaydet <şehir>` - Şehri kişisel listene kaydeder.\n"
        "`!şehirlerimi_göster` - Kaydettiğin tüm şehirleri tek haritada gösterir.\n\n"
        "Not: Şehir adlarını veri tabanındaki İngilizce adlarıyla yazman en iyi sonucu verir. "
        "Örnek: `!şehri_göster Istanbul`"
    )


@bot.command()
async def şehri_göster(ctx: commands.Context, *, city_name=""):
    city_name = city_name.strip()

    if not city_name:
        await ctx.send("Kullanım: `!show_city <şehir>`\nÖrnek: `!show_city Istanbul`")
        return

    if manager.get_coordinates(city_name) is None:
        await ctx.send(
            f"`{city_name}` veri tabanında bulunamadı. Şehir adını İngilizce olarak kontrol et."
        )
        return

    await send_map(ctx, [city_name], f"📍 **{city_name}** haritada gösteriliyor:")


@bot.command()
async def şehirlerimi_göster(ctx: commands.Context):
    cities = manager.select_cities(ctx.author.id)

    if not cities:
        await ctx.send(
            "Henüz kayıtlı şehrin yok. Önce `!şehri kaydet <şehir>` komutunu kullan."
        )
        return

    city_list = ", ".join(cities)
    await send_map(
        ctx,
        cities,
        f"🗺️ Kaydettiğin şehirler: **{city_list}**",
    )


@bot.command()
async def şehri_kaydet(ctx: commands.Context, *, city_name=""):
    city_name = city_name.strip()

    if not city_name:
        await ctx.send("Kullanım: `!remember_city <şehir>`\nÖrnek: `!remember_city Antalya`")
        return

    if manager.add_city(ctx.author.id, city_name):
        await ctx.send(f"✅ **{city_name}** şehri başarıyla kaydedildi!")
    else:
        await ctx.send(
            "Şehir bulunamadı. Lütfen şehir adını İngilizce olarak ve komuttan sonra bir boşluk bırakarak gir."
        )


@bot.event
async def on_command_error(ctx: commands.Context, error):
    if isinstance(error, commands.CommandNotFound):
        await ctx.send("Böyle bir komut yok. Komutları görmek için `!yardım_et` yazabilirsin.")
        return
    raise error


if __name__ == "__main__":
    if not TOKEN:
        raise RuntimeError(
            "Discord bot tokeni bulunamadı. DISCORD_TOKEN ortam değişkenini ayarlayıp tekrar çalıştır."
        )

    bot.run(TOKEN)
