import os

TOKEN = "buraya token"