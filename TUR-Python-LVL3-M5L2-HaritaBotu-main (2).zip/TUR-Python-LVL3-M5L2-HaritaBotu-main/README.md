# 🗺️ Harita Botu

Bu proje, Discord üzerinden şehirleri dünya haritasında göstermeyi ve kullanıcıların seçtiği şehirleri SQLite veri tabanında kaydetmeyi sağlayan bir bottur.

Projeyle birlikte gelen `database.db` dosyasında dünyanın çok sayıda şehri, enlem ve boylam bilgileriyle birlikte bulunur.

## Özellikler

- Belirtilen bir şehri dünya haritasında işaretler.
- Kullanıcının seçtiği şehirleri kişisel listesine kaydeder.
- Kullanıcının kaydettiği tüm şehirleri tek bir haritada gösterir.
- Haritaları Cartopy + Matplotlib ile PNG olarak oluşturur ve Discord'a gönderir.
- Kullanıcıların şehir listelerini SQLite ile saklar.

## Proje dosyaları

- `bot.py` — Discord komutları ve botun ana çalışma dosyası.
- `logic.py` — SQLite işlemleri ve harita oluşturma fonksiyonları.
- `database.db` — Şehirler ve koordinatlarını içeren veri tabanı.
- `config.py` — Discord tokenini ortam değişkeninden okur.
- `requirements.txt` — Gerekli Python paketleri.

## Kurulum

### 1. Projeyi aç

```bash
git clone <depo_baglantisi>
cd <depo_adi>
```

### 2. Sanal ortam oluşturmak istersen

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 3. Paketleri yükle

```powershell
python -m pip install -r requirements.txt
```

## Discord tokenini ayarlama

Bot tokenini doğrudan `config.py` içine yazmak yerine ortam değişkeni kullanılır. Böylece token yanlışlıkla GitHub'a yüklenmez.

Windows PowerShell'de, botu çalıştıracağın terminalde:

```powershell
$env:DISCORD_TOKEN="BURAYA_BOT_TOKENIN"
```

Ardından:

```powershell
python bot.py
```

Bot komutları mesajları okuyacağı için Discord Developer Portal'da botunun gerekli intent ayarlarının açık olduğundan emin ol.

## Komutlar

| Komut | Açıklama |
|---|---|
| `!start` | Karşılama mesajını gösterir. |
| `!help_me` | Kullanılabilir komutları listeler. |
| `!show_city <şehir>` | Belirtilen şehri haritada gösterir. |
| `!remember_city <şehir>` | Belirtilen şehri kullanıcı listesine kaydeder. |
| `!show_my_cities` | Kullanıcının kaydettiği tüm şehirleri haritada gösterir. |

## Örnek kullanım

```text
!show_city Istanbul
!remember_city Istanbul
!remember_city Antalya
!show_my_cities
```

Şehir isimlerini veri tabanındaki İngilizce adlarıyla yazmak en iyi sonucu verir. Aramalar büyük/küçük harfe duyarlı değildir; örneğin `istanbul` da kabul edilir.

## `create_graph()` fonksiyonu

`logic.py` içindeki `create_graph(path, cities)` fonksiyonu:

1. Şehirlerin koordinatlarını veri tabanından alır.
2. Cartopy ile dünya haritası oluşturur.
3. Her şehrin konumuna kırmızı bir işaret ve şehir etiketi ekler.
4. Haritayı belirtilen `path` konumuna PNG olarak kaydeder.
5. Bot bu PNG dosyasını Discord mesajına ekler.

## GitHub'a yükleme

Tokeni repoya eklemeden aşağıdaki gibi yükleyebilirsin:

```bash
git add .
git commit -m "Harita botu projesini tamamla"
git push
```

> **Önemli:** Discord bot tokenini hiçbir zaman GitHub'a commit etme. Tokeninin açığa çıktığını düşünüyorsan yenisini oluştur.
